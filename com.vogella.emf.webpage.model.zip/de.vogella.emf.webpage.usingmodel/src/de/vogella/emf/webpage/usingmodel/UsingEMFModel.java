package de.vogella.emf.webpage.usingmodel;

import de.vogella.webpage.model.webpage.WebpagePackage;
import webpage.Web;
import webpage.WebPage;
import webpage.WebpageFactory;



public class UsingEMFModel {
    public static void main(String[] args) {
    	// Retrieve the default factory singleton
        WebpageFactory factory = WebpageFactory.eINSTANCE;
        // create an instance of myWeb
        Web myWeb = factory.createWeb();
        myWeb.setName("Hallo");
        myWeb.setTitle("This is a description");
        myWeb.setKeywords("web, the");
        // create a page
        WebPage webpage = factory.createWebPage();
        webpage.setName("This is a title");
        // add the page to myWeb
        myWeb.getWebpages().add(webpage);
        // and so on, and so on
        System.out.println(myWeb.toString());
        // as you can see the EMF model can be (more or less) used as standard Java
    }
}